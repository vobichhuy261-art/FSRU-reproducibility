"""Counterexample and rejection checks for the reusable consumer audit."""
import unittest
from consumer_audit import audit_consumption, assign_consumed_folds


class ConsumerTests(unittest.TestCase):
    def test_intact_group_order_can_fail_under_fixed_slices(self):
        groups = ['A'] * 4 + ['B'] * 4 + ['C'] * 3
        intended = [0] * 4 + [1] * 4 + [2] * 3
        report = audit_consumption(groups, list(range(11)), [0, 3, 6, 11], intended)
        self.assertEqual(report['intended_cross_fold_identity_groups'], 0)
        self.assertEqual(report['cross_fold_identity_groups'], 2)
        self.assertEqual(report['rows_in_cross_fold_groups'], 8)
        self.assertEqual(report['rows_changing_fold_between_rules'], 3)

    def test_explicit_producer_boundaries_keep_groups(self):
        report = audit_consumption(['A'] * 4 + ['B'] * 4 + ['C'] * 3, list(range(11)), [0, 4, 8, 11])
        self.assertTrue(report['consumed_group_disjoint'])

    def test_nonidentity_permutation_uses_source_row_ids(self):
        actual = assign_consumed_folds([4, 5, 0, 1, 2, 3], 6, [0, 2, 4, 6])
        self.assertEqual(actual, [1, 1, 2, 2, 0, 0])

    def test_incomplete_or_repeated_order_rejected(self):
        for order in [[0, 0, 2], [0, 1], [0, 1, 3]]:
            with self.assertRaisesRegex(ValueError, 'complete row permutation'):
                assign_consumed_folds(order, 3, [0, 1, 3])

    def test_invalid_cut_points_rejected(self):
        for cuts in [[0, 2, 2, 3], [1, 2, 3], [0, 2, 4]]:
            with self.assertRaisesRegex(ValueError, 'Boundaries'):
                assign_consumed_folds(list(range(3)), 3, cuts)


if __name__ == '__main__':
    unittest.main()
