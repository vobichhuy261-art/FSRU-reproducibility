# Saved-result verification package

This is local review staging. No upload or publication has been performed.

Run `python verify_export.py` with Python 3.9+; only the standard library is needed. It verifies all prediction identities, file hashes, probability validity, fold macro F1 and pooled OOF macro F1.

Optionally run `python verify_export.py --bootstrap` with NumPy 1.26.2 to replay all eight reported component intervals and bootstrap means.

The 13 prediction files represent 65 fold-model-seed sets, including 50 new and 15 historical runs. Candidate components are operational dependence proxies, not certified independent events. All new analyses use development-exposed partitions and remain exploratory.

Raw content, frozen features, checkpoints and inherited training code are excluded. This package supports saved-result verification, not end-to-end training reproduction.
