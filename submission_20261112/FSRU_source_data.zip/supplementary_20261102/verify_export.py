"""Verify anonymized supplementary predictions using Python's standard library."""
import argparse
import csv
import hashlib
import json
import math
import statistics
from pathlib import Path


def macro_f1(cells):
    tn, fp, fn, tp = cells
    d0, d1 = 2 * tn + fp + fn, 2 * tp + fp + fn
    return ((2 * tn / d0 if d0 else 0) + (2 * tp / d1 if d1 else 0)) / 2


def verify(directory):
    package = json.loads((directory / 'package.json').read_text(encoding='utf-8'))
    manifest_path = directory / 'anonymous_manifest.csv'
    if hashlib.sha256(manifest_path.read_bytes()).hexdigest() != package['anonymous_manifest_sha256']:
        raise ValueError('Anonymous manifest changed')
    manifest = list(csv.DictReader(manifest_path.open(encoding='utf-8', newline='')))
    if [int(r['sample_index']) for r in manifest] != list(range(package['rows'])):
        raise ValueError('Manifest row order or coverage changed')
    owners = {}
    for row in manifest:
        group = int(row['candidate_component'])
        assignment = (int(row['outer_fold']), row['inner_validation_for'])
        if group in owners and owners[group] != assignment:
            raise ValueError('Anonymous component crosses a train/validation/test boundary')
        owners[group] = assignment
    if set(owners) != set(range(package['candidate_components'])):
        raise ValueError('Anonymous component identities changed')
    verified = 0
    for entry in package['prediction_files']:
        path = directory / entry['filename']
        if hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
            raise ValueError('Prediction file changed: ' + path.name)
        rows = list(csv.DictReader(path.open(encoding='utf-8', newline='')))
        if len(rows) != len(manifest):
            raise ValueError('Prediction coverage differs')
        cells = [[0] * 4 for _ in range(5)]
        pooled = [0] * 4
        for i, row in enumerate(rows):
            label, fold = int(row['label']), int(row['outer_fold'])
            if int(row['sample_index']) != i or label != int(manifest[i]['label']) or fold != int(manifest[i]['outer_fold']):
                raise ValueError('Prediction identities or labels differ from manifest')
            p0, p1 = float(row['probability_0']), float(row['probability_1'])
            if not (math.isfinite(p0) and math.isfinite(p1) and 0 <= p0 <= 1 and 0 <= p1 <= 1 and abs(p0 + p1 - 1) < 1e-5):
                raise ValueError('Invalid probabilities')
            # Match NumPy argmax: ties go to class zero.
            prediction = int(p1 > p0)
            cell = 2 * label + prediction
            cells[fold][cell] += 1; pooled[cell] += 1
        scores = [macro_f1(c) for c in cells]
        for a, b in zip(scores, entry['fold_macro_f1']):
            if abs(a - b) > 1e-10:
                raise ValueError('Fold metric replay mismatch')
        if abs(statistics.mean(scores) - entry['fold_mean_macro_f1']) > 1e-10:
            raise ValueError('Fold-mean metric replay mismatch')
        if abs(macro_f1(pooled) - entry['pooled_oof_macro_f1']) > 1e-10:
            raise ValueError('Pooled OOF metric replay mismatch')
        verified += 1
    return {'verified_prediction_files': verified, 'rows_per_file': len(manifest),
            'verified_fold_prediction_sets': verified * 5, 'standard_library_only': True}


def verify_bootstrap(directory):
    """Optional NumPy replay of every reported component interval."""
    import numpy as np
    package = json.loads((directory / 'package.json').read_text(encoding='utf-8'))
    report = json.loads((directory / 'verified_analysis.json').read_text(encoding='utf-8'))
    manifest = list(csv.DictReader((directory / 'anonymous_manifest.csv').open(encoding='utf-8', newline='')))
    labels = np.array([int(r['label']) for r in manifest])
    group_index = np.array([int(r['candidate_component']) for r in manifest])
    groups = package['candidate_components']
    weights = np.random.default_rng(20261102).multinomial(groups, np.full(groups, 1 / groups), size=10000)
    predictions = {}
    for entry in package['prediction_files']:
        rows = list(csv.DictReader((directory / entry['filename']).open(encoding='utf-8', newline='')))
        predictions[(entry['model'], entry['seed'])] = np.array(
            [int(float(r['probability_1']) > float(r['probability_0'])) for r in rows])

    def draw_scores(model, seeds):
        cells = np.zeros((len(seeds), groups, 4), dtype=np.int64)
        for i, seed in enumerate(seeds):
            np.add.at(cells[i], (group_index, 2 * labels + predictions[(model, seed)]), 1)
        c = np.einsum('bg,sgc->bsc', weights, cells, optimize=True).astype(float)
        d0, d1 = 2 * c[..., 0] + c[..., 1] + c[..., 2], 2 * c[..., 3] + c[..., 1] + c[..., 2]
        f0 = np.divide(2 * c[..., 0], d0, out=np.zeros_like(d0), where=d0 != 0)
        f1 = np.divide(2 * c[..., 3], d1, out=np.zeros_like(d1), where=d1 != 0)
        return ((f0 + f1) / 2).mean(1)

    verified = 0

    def check(values, expected):
        nonlocal verified
        if not np.allclose(np.percentile(values, [2.5, 97.5]), expected['percentile_95_interval'], atol=1e-10, rtol=0):
            raise ValueError('Component-bootstrap interval replay mismatch')
        if abs(float(np.mean(values)) - expected['bootstrap_mean']) > 1e-10:
            raise ValueError('Component-bootstrap mean replay mismatch')
        verified += 1

    reference = draw_scores('context', [30, 31, 32])
    for control, expected in report['comparisons'].items():
        check(reference - draw_scores(control, [30, 31, 32]), expected)
    factorial = {model: draw_scores(model, [30]) for model in
                 ['geometry_1d_shared', 'geometry_1d_perbin', 'geometry_2d_perbin', 'context_ffn_active']}
    factorial['geometry_2d_shared'] = draw_scores('context', [30])
    for contrast, expected in report['factorial']['contrasts'].items():
        first, second = contrast.split('_minus_')
        check(factorial[first] - factorial[second], expected)
    interaction = (factorial['geometry_2d_shared'] - factorial['geometry_1d_shared'] -
                   factorial['geometry_2d_perbin'] + factorial['geometry_1d_perbin'])
    check(interaction, report['factorial']['geometry_by_sharing_interaction'])
    return {'verified_component_intervals': verified, 'draws': 10000, 'numpy': np.__version__}


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--directory', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--bootstrap', action='store_true', help='also replay intervals; requires NumPy')
    args = parser.parse_args()
    result = verify(args.directory)
    if args.bootstrap:
        result['bootstrap'] = verify_bootstrap(args.directory)
    print(json.dumps(result, indent=2))
