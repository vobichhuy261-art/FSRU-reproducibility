# Supplementary robustness and attribution experiments

Draft addendum for author review. The existing submission package has not been overwritten.

## Methods

We extended the existing Twitter candidate-component experiment with optimization seeds 31 and 32, retaining seed 30. The 10,203 posts, 355 candidate components, five explicit outer partitions, inner validation assignments, frozen BERTweet token features and frozen CLIP patch features were unchanged. Each model was trained separately on each fold and seed. Checkpoints were selected by the first maximum inner-validation macro F1, with batch size 32, AdamW learning rate 0.001, weight decay 0.01, at most 50 epochs and patience 10. Cross-entropy and the two contrastive terms retained coefficients 1, 0.2 and 0.2, respectively. The additional runs used the existing training implementation and hash-bound inputs. The folds had previously been inspected during development; these experiments remain exploratory.

For each seed, we report the unweighted mean of the five outer-fold macro-F1 values separately from macro F1 computed after pooling all out-of-fold predictions. The sample standard deviation across the three seed-specific fold means describes optimization variability on fixed partitions. It is not a standard error over independent datasets. For paired uncertainty summaries, 355 candidate components were sampled with replacement in each of 10,000 draws (NumPy RNG seed 20261102). Each draw used the same component multiplicities for every model and seed. We computed the pooled-OOF macro-F1 contrast within each seed and averaged the three contrasts. Percentile intervals condition on the saved fitted models and fixed seeds; they do not include retraining uncertainty. The intervals are descriptive and unadjusted for multiplicity.

We separately compared 1D and 2D image-frequency geometry with shared and per-bin complex gains at seed 30 on all five folds. All geometry controls retained the same two-band gating networks, text filter, input projections, pooling and classifier. Common modules had identical initial weights within a seed. Per-bin gains were initialized by expanding their corresponding shared-band gains, yielding equal initial functions within each geometry. The 1D transform operated on the row-major 196-patch sequence; the 2D transform operated on the 14 x 14 grid. Geometry therefore also changed the frequency support and associated band populations. Per-bin models had additional gain parameters and were not capacity-matched to shared models. The existing 2D/shared seed-30 run served as the reference after numerical forward-equivalence checks.

An additional residual control used hidden width 322. Its 1,386,886 parameters were approximately matched to the 1,386,786 parameters in spectral-model tensors connected to the forward/backward probe, a difference of 100 (0.0072%). The spectral model also registered an unused 32,768-element text-weight tensor. This accounting excludes wholly unused tensors but does not establish equal functional capacity or count only nonzero scalar gradients. We retained the larger and original nominal-count residual controls.

## Results: optimization-seed robustness

| Model | Seed 30 fold mean | Seed 31 fold mean | Seed 32 fold mean | Mean ± seed SD | Mean seed pooled OOF |
|---|---:|---:|---:|---:|---:|
| Spectral | 0.880340 | 0.882431 | 0.885339 | 0.882703 ± 0.002510 | 0.890852 |
| Larger residual | 0.879122 | 0.910910 | 0.896513 | 0.895515 ± 0.015917 | 0.903613 |
| Nominal-count residual | 0.892552 | 0.899193 | 0.898555 | 0.896766 ± 0.003664 | 0.905909 |

All intervals below concern the mean of seed-specific pooled-OOF contrasts, rather than subtraction of unweighted fold means.

- Spectral minus larger residual: mean pooled-OOF difference -0.012761; conditional 95% percentile interval [-0.041897, 0.012698].
- Spectral minus nominal-count residual: mean pooled-OOF difference -0.015056; conditional 95% percentile interval [-0.038719, 0.005291].

## Results: single-seed attribution controls

| Model | Seed-30 unweighted fold mean | Seed-30 pooled OOF macro F1 |
|---|---:|---:|
| 2D/shared | 0.880340 | 0.888061 |
| 1D/shared | 0.893976 | 0.901971 |
| 1D/per-bin | 0.883063 | 0.891782 |
| 2D/per-bin | 0.896591 | 0.904804 |
| Forward-connected-count residual | 0.900843 | 0.908067 |

Paired pooled-OOF contrasts (seed 30 only):

- 2D/shared minus 1D/shared: -0.013910; conditional interval [-0.078323, 0.047674].
- 2D/per-bin minus 1D/per-bin: 0.013021; conditional interval [-0.020664, 0.053876].
- 2D/shared minus 2D/per-bin: -0.016743; conditional interval [-0.074126, 0.034953].
- 1D/shared minus 1D/per-bin: 0.010188; conditional interval [-0.023877, 0.052887].
- 2D/shared minus Forward-connected-count residual: -0.020006; conditional interval [-0.054529, 0.011016].

The descriptive geometry-by-sharing interaction, (2D/shared - 1D/shared) - (2D/per-bin - 1D/per-bin), was -0.026931, with conditional interval [-0.121013, 0.054314]. These single-seed controls separate specified implementation factors but do not establish a general mechanism or prospective advantage.

## Verification and placement

All 65 fold-model-seed prediction sets (15 existing and 50 additional) were checked for target-manifest binding, complete exactly-once OOF coverage, probability validity, checkpoint selection and replayed metrics. The original submission files were unchanged at verification. Full predictions and fold metrics belong in the supplementary source data. The main text should replace its single-seed summary and unresolved-attribution statements with a concise account of these results and their limits, rather than append repeated numerical descriptions. The parameter and operator distinctions should remain in Methods. The earlier available-case external diagnostic remains necessary; these runs do not repair its media coverage.


## Checkpoint-to-prediction verification

All 65 saved checkpoints were independently evaluated on their exact outer-fold rows. Every argmax prediction matched the saved prediction; the maximum absolute probability difference was 1.19e-07 (absolute tolerance 1e-6, relative tolerance 1e-5). This verifies correspondence between weights and saved predictions, in addition to the separate metric and sample-identity checks. It does not establish annotation correctness or semantic/event independence.


## Cached-input forward timing

On the RTX 4050 laptop GPU, all seven heads were timed at batch size 32 and float32 using the same first 32 hash-bound input rows. After 20 warm-up batches per head, 100 timed batches were recorded in a fixed model order. The measurements include projections and fusion, with encoder inference, cache I/O and host/device transfer excluded. Interquartile ranges summarize repeated timing measurements, not independent experimental replicates or confidence intervals. Desktop activity and thermal state were uncontrolled.

| Head | Median CUDA batch time (ms) | Timing interquartile range (ms) |
|---|---:|---:|
| Spectral | 3.578 | [3.162, 3.834] |
| Larger residual | 3.456 | [3.347, 3.596] |
| Nominal-count residual | 1.933 | [1.870, 2.052] |
| Forward-connected-count residual | 1.928 | [1.854, 2.040] |
| 1D/shared | 3.105 | [2.980, 3.201] |
| 1D/per-bin | 3.090 | [2.965, 3.187] |
| 2D/per-bin | 3.135 | [3.039, 3.280] |

The 2D/shared spectral head did not show a forward-time advantage over the two count-comparable residual heads in this session. Filter-specific parameter savings should therefore remain separate from claims about full-model speed or deployment throughput.
