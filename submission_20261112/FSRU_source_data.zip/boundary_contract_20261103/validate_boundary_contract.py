"""Architecture-independent boundary-check validation against an independent oracle."""
import sys,json,random,itertools,hashlib
from pathlib import Path
P=Path(__file__).parent
sys.path.insert(0,str(P))
from consumer_audit import audit_consumption
rng=random.Random(20261103)
cases=[]
for n in range(2,101):
 for _ in range(30):
  k=rng.randint(2,min(n,10));cuts=[0]+sorted(rng.sample(range(1,n),k-1))+[n]
  groups=[str(rng.randrange(max(1,n//3))) for _ in range(n)]
  order=list(range(n));rng.shuffle(order)
  # Independently construct consumed row sets instead of reusing audit assignment code.
  folds=[set(order[a:b]) for a,b in zip(cuts,cuts[1:])]
  ids={g:{i for i,x in enumerate(groups) if x==g} for g in set(groups)}
  crossed=[v for v in ids.values() if sum(bool(v & f) for f in folds)>1]
  expected=(len(crossed),sum(map(len,crossed)))
  r=audit_consumption(groups,order,cuts)
  assert (r['cross_fold_identity_groups'],r['rows_in_cross_fold_groups'])==expected
  # Identity renaming and within-fold permutations must preserve the result.
  relabel={g:str(i+1000) for i,g in enumerate(ids)}
  renamed=audit_consumption([relabel[g] for g in groups],order,cuts)
  shuffled=[]
  for f in folds:
   seq=sorted(f);rng.shuffle(seq);shuffled.extend(seq)
  within=audit_consumption(groups,shuffled,cuts)
  assert all(v['cross_fold_identity_groups']==expected[0] and v['rows_in_cross_fold_groups']==expected[1] for v in [renamed,within])
  cases.append((n,k))
invalid=[(['a','b'],[0,0],[0,1,2]),(['a','b'],[0,1],[0,0,2]),(['a','b'],[0,1],[0,1,3]),(['a','b'],[0,1],[1,2])]
for args in invalid:
 try:audit_consumption(*args)
 except ValueError:pass
 else:raise AssertionError('Invalid input accepted')
r={'status':'passed','seed':20261103,'random_partitions':len(cases),'oracle_checks':len(cases),'metamorphic_checks':2*len(cases),'invalid_inputs_rejected':len(invalid),'row_range':[2,100],'fold_range':[2,10],'source_sha256':hashlib.sha256((P/'consumer_audit.py').read_bytes()).hexdigest(),'scope':'Synthetic software verification of a model-independent consumer boundary contract. Not evidence that benchmark errors occur in all architectures or that a model generalizes.'}
(P/'boundary_contract_validation.json').write_text(json.dumps(r,indent=2),encoding='utf-8');print(json.dumps(r))
