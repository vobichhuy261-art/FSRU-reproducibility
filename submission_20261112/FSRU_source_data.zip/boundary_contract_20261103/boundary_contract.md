# Reusable consumer boundary contract

For a row permutation π and consumed fold boundaries c, let r(i) be the position of row i in π. A group is contained in one consumed fold if and only if no internal consumed boundary c_j satisfies min r(i) < c_j ≤ max r(i), over members of that group. This is a direct consequence of assigning the consecutive intervals [c_j,c_(j+1)) to folds. The criterion also covers groups whose members are not contiguous in the permutation.

This is an elementary implementation invariant, not a claim to invent grouped cross-validation. Its role is to validate the indices after all transformations and slicing, independently of the neural architecture. The tested identities must be stated explicitly; image-ID isolation cannot certify perceptual, event or temporal independence.

The portable checker in competitiveness_20261102/consumer_audit.py implements the equivalent per-group consumed-fold cardinality test. validate_boundary_contract.py compares it against an independently constructed set-intersection oracle over 2,970 generated partitions with 2–100 rows and 2–10 folds. Group renaming and permutations within consumed folds add 5,940 invariant checks; four malformed order/boundary cases must raise ValueError. All passed. These are synthetic software-validation cases, not additional scientific datasets or model repetitions.

The existing two historical Twitter replays provide actual observed failures. The existing fixed candidate-group Twitter and Weibo input audits provide separate checks of explicit group-disjoint training, inner validation and outer test assignments. Neither the synthetic cases nor these checks establish that failures occur in all published systems.

All reported check counts are computed by the accompanying program.
