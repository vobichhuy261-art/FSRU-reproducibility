"""Portable audit of the partitions a permutation consumer actually creates.

Example (no training or raw media needed):
  python consumer_audit.py --rows train_then_test.csv --group-column image_url
      --permutation split.npy --folds 5 --out report.json --strict

The CSV order must be exactly the consumer's source row order. A passing
image-ID audit does not establish perceptual, event, or temporal independence.
"""
import argparse
import csv
import hashlib
import json
from collections import defaultdict
from pathlib import Path


def assign_consumed_folds(order, n, boundaries):
    if len(order) != n or sorted(order) != list(range(n)):
        raise ValueError('Consumer order must be a complete row permutation')
    if len(boundaries) < 2 or boundaries[0] != 0 or boundaries[-1] != n or any(b <= a for a, b in zip(boundaries, boundaries[1:])):
        raise ValueError('Boundaries must strictly increase from zero to the row count')
    assignments = [-1] * n
    for fold, (start, end) in enumerate(zip(boundaries, boundaries[1:])):
        for index in order[start:end]:
            assignments[index] = fold
    return assignments


def audit_consumption(groups, order, boundaries, intended=None):
    consumed = assign_consumed_folds(order, len(groups), boundaries)
    members = defaultdict(list)
    for index, group in enumerate(groups):
        members[str(group)].append(index)
    crossing = [indices for indices in members.values() if len({consumed[i] for i in indices}) > 1]
    result = {'rows': len(groups), 'identity_groups': len(members),
              'consumed_boundaries': boundaries,
              'consumed_fold_sizes': [b - a for a, b in zip(boundaries, boundaries[1:])],
              'cross_fold_identity_groups': len(crossing),
              'rows_in_cross_fold_groups': sum(map(len, crossing)),
              'fraction_rows_in_cross_fold_groups': sum(map(len, crossing)) / len(groups),
              'consumed_group_disjoint': not crossing}
    if intended is not None:
        if len(intended) != len(groups) or set(intended) != set(range(len(boundaries) - 1)):
            raise ValueError('Intended per-row fold IDs have wrong size or coverage')
        result['intended_cross_fold_identity_groups'] = sum(len({intended[i] for i in ids}) > 1 for ids in members.values())
        result['rows_changing_fold_between_rules'] = sum(a != b for a, b in zip(intended, consumed))
    result['interpretation'] = 'Assignment audit only. Exposed-group rows are not a count of proven misclassified rows or a causal accuracy effect.'
    return result


def main(args):
    import numpy as np
    rows = list(csv.DictReader(args.rows.open(encoding='utf-8-sig', newline='')))
    groups = [row[args.group_column] for row in rows]
    if not rows or any(group == '' for group in groups):
        raise ValueError('CSV is empty or contains empty group identities')
    order = np.load(args.permutation, allow_pickle=False)
    if order.ndim != 1 or not np.issubdtype(order.dtype, np.integer):
        raise ValueError('Permutation must be a one-dimensional integer NPY array')
    n = len(rows)
    if args.folds < 2 or args.folds > n:
        raise ValueError('Invalid fold count')
    boundaries = args.boundaries or [k * (n // args.folds) for k in range(args.folds)] + [n]
    if len(boundaries) != args.folds + 1:
        raise ValueError('Boundary count must equal folds + 1')
    intended = None
    if args.intended_folds:
        array = np.load(args.intended_folds, allow_pickle=False)
        if array.ndim != 1 or not np.issubdtype(array.dtype, np.integer):
            raise ValueError('Intended fold IDs must be a one-dimensional integer NPY array')
        intended = array.tolist()
    result = audit_consumption(groups, order.tolist(), boundaries, intended)
    result['source_sha256'] = {str(p): hashlib.sha256(p.read_bytes()).hexdigest()
                               for p in [args.rows, args.permutation] + ([args.intended_folds] if args.intended_folds else [])}
    args.out.write_text(json.dumps(result, indent=2), encoding='utf-8')
    print(json.dumps({k: result[k] for k in ['rows', 'cross_fold_identity_groups', 'rows_in_cross_fold_groups', 'consumed_group_disjoint']}))
    if args.strict and not result['consumed_group_disjoint']:
        raise SystemExit(1)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--rows', type=Path, required=True)
    parser.add_argument('--group-column', required=True)
    parser.add_argument('--permutation', type=Path, required=True)
    parser.add_argument('--folds', type=int, default=5)
    parser.add_argument('--boundaries', type=int, nargs='+')
    parser.add_argument('--intended-folds', type=Path)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--strict', action='store_true')
    main(parser.parse_args())
