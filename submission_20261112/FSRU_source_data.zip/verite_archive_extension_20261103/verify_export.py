import csv,json,math
from pathlib import Path
R=Path(__file__).parent
rows=list(csv.DictReader((R/'predictions.csv').open()))
assert len(rows)==998 and len({r['row'] for r in rows})==998
report=json.loads((R/'report.json').read_text())
for family in ['context','context_ffn']:
 cells=[0,0,0,0]
 for r in rows:
  pp=[float(r[family+'_ensemble_prob_'+str(c)]) for c in [0,1]]
  assert all(math.isfinite(x) and 0<=x<=1 for x in pp) and abs(sum(pp)-1)<1e-5
  for c in [0,1]:assert abs(pp[c]-sum(float(r[family+'_fold'+str(f)+'_prob_'+str(c)]) for f in range(5))/5)<1e-7
  cells[2*int(r['label'])+int(pp[1]>pp[0])]+=1
 tn,fp,fn,tp=cells
 f=(2*tn/(2*tn+fp+fn)+2*tp/(2*tp+fp+fn))/2
 assert abs(f-report['results'][family]['macro_f1'])<1e-12
 print(family,f,cells)
print('PASS 998rows,5fold means and binary macroF1; no raw media required')
