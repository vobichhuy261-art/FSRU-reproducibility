# Three-seed extension source data

The 24 prediction files each contain 10,203 anonymous rows, covering 120 model-fold-seed sets. Indices and group codes bind to anonymous_manifest.csv; this preserves the previous candidate-group assignment. No raw text, images, encoder features, binary weights or third-party model source are redistributed.

Run `python verify_export.py` to verify all probabilities and fold/pooled metrics using the standard library. Add `--bootstrap` with NumPy 1.26.2 to replay all nine conditional component intervals, including the geometry-sharing interaction. Intervals hold fitted seeds fixed, use 10,000 draws at seed20261102, and are exploratory and unadjusted.

CAFE uses the author architecture with documented common-feature dimensional, seed, shape, label and selection adaptations. It is not an exact reproduction of the original system. The recorded mean is not a state-of-the-art ranking. Author source is excluded because no redistribution license was confirmed.

The companion boundary_contract_20261103 directory verifies the model-independent software invariant. Synthetic checks are not extra empirical datasets. VERITE is still limited to the existing681 available cases. Original-media access and complete external re-evaluation remain pending.

The figures and reported metrics are computed from the accompanying recorded results.
