"""Draw the actual matched contextual fusion-head comparison at 172 mm width.

Rebuild: python build_architecture.py
Dependencies: matplotlib (tested 3.9.4), numpy, Pillow; Python >=3.9.
All outputs and helper imports are relative to this script. No model/data loads.
This schematic describes operations and does not encode performance claims.
"""
from pathlib import Path
import sys, json, hashlib, re

HERE = Path(__file__).resolve().parent
try:
    import matplotlib
except ImportError:
    for ancestor in HERE.parents:
        candidate = ancestor / '.venv/Lib/site-packages'
        if candidate.is_dir(): sys.path.insert(0, str(candidate))
    import matplotlib
matplotlib.use('Agg')
import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
try:
    from audit_panel_alignment import require_matplotlib_panel_alignment
except ImportError:
    require_matplotlib_panel_alignment = None

WIDTH_MM = 172
HEIGHT_MM = 150
MIN_PT = 7.2
INK, LINE = '#19313e', '#526b78'
BLUE, PALE_BLUE = '#286b8d', '#e7f1f6'
PALE, WHITE = '#f3f5f6', '#ffffff'
mpl.rcParams.update({
    'font.family': 'sans-serif', 'font.sans-serif': ['Arial', 'DejaVu Sans'],
    'font.size': 7.4, 'svg.fonttype': 'none', 'pdf.fonttype': 42,
    'savefig.facecolor': 'white', 'figure.facecolor': 'white',
})

def build():
    fig = plt.figure(figsize=(WIDTH_MM/25.4, HEIGHT_MM/25.4))
    ax = fig.add_axes([0, 0, 1, 1])
    ax.set(xlim=(0, WIDTH_MM), ylim=(0, HEIGHT_MM)); ax.set_axis_off()
    labels, boxes, edges = [], [], []

    def text(x, y, label, *, size=7.4, bold=False, gid=''):
        t=ax.text(x, y, label, ha='center', va='center', fontsize=size,
                  color=INK, fontweight='bold' if bold else 'normal')
        if gid:t.set_gid(gid)
        labels.append(t);return t

    def box(gid, x, y, w, h, *, fill=PALE, color=LINE, lw=.7):
        p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0,rounding_size=1.0',
                        facecolor=fill,edgecolor=color,linewidth=lw)
        p.set_gid(gid);ax.add_patch(p);boxes.append({'id':gid,'rect_mm':[x,y,w,h]});return p

    def arrow(gid, xy1, xy2, *, color=LINE, lw=.8):
        p=FancyArrowPatch(xy1,xy2,arrowstyle='-|>',mutation_scale=6.0,
                          color=color,linewidth=lw,shrinkA=0,shrinkB=0)
        p.set_gid(gid);ax.add_patch(p);edges.append({'id':gid,'start_mm':xy1,'end_mm':xy2})

    def segment(gid, points, *, color=LINE, lw=.8):
        xx,yy=zip(*points);ln=ax.plot(xx,yy,color=color,lw=lw,solid_capstyle='butt')[0]
        ln.set_gid(gid);edges.append({'id':gid,'points_mm':points})

    text(86,146,'Matched fusion-head comparison',size=9.0,bold=True,gid='title')
    # Frozen representations are identical inputs to the compared model families.
    box('input_text',4,128,80,13,fill=WHITE)
    text(44,136.1,'Text features: L × 768 + validity mask',gid='input_text_shape')
    text(44,131.8,'Frozen contextual tokens / static lookup control',size=7.2,gid='input_text_encoder')
    box('input_image',88,128,80,13,fill=WHITE)
    text(128,136.1,'Image patches: 14 × 14 × 768',gid='input_image_shape')
    text(128,131.8,'Frozen CLIP ViT-B/16',size=7.2,gid='input_image_encoder')
    arrow('text_to_projection',(44,128),(44,122))
    arrow('image_to_projection',(128,128),(128,122))
    # One container holds separate modality operations, never an early sum.
    box('common_projections',4,108,164,14,fill=PALE)
    text(44,117.4,'Text Linear(768,256) + LayerNorm',gid='text_projection')
    text(44,112.5,'Position encoding; mask reapplied',size=7.2,gid='text_position_mask')
    text(128,117.4,'Image Linear(768,256) + LayerNorm',gid='image_projection')
    text(128,112.5,'196 projected patch tokens',size=7.2,gid='image_projection_shape')
    # Connector transports a tuple of separate tensors, not an additive merge.
    segment('tuple_connector',[(86,108),(86,104),(60,104)])
    segment('tuple_branch',[(86,104),(144,104)])
    arrow('tuple_to_spectral',(60,104),(60,100))
    arrow('tuple_to_residual',(144,104),(144,100))
    text(97,105.8,'T, I',size=7.2,gid='tuple_label')

    # Alternative fusion heads, not an ensemble. Spectral detail needs more area.
    box('spectral_container',4,49,112,51,fill=WHITE,color=BLUE,lw=.9)
    text(60,96,'a  Spectral head: FtLayer2D',size=8.2,bold=True,gid='spectral_title')
    box('text_spectral_filter',10,81,47,10,fill=PALE_BLUE,color=BLUE)
    text(33.5,87.4,'Text: rFFT1D',gid='text_fft')
    text(33.5,83.6,'Complex-square filter bank',size=7.2,gid='text_complex_filter')
    box('image_spectral_filter',63,81,47,10,fill=PALE_BLUE,color=BLUE)
    text(86.5,87.4,'Image: rFFT2D',gid='image_fft')
    text(86.5,83.6,'Band-shared complex gains',size=7.2,gid='image_gain')
    arrow('text_filtered_to_gates',(33.5,81),(33.5,78),color=BLUE)
    arrow('image_filtered_to_gates',(86.5,81),(86.5,78),color=BLUE)
    box('sequential_gates',10,63,100,15,fill=PALE_BLUE,color=BLUE)
    text(60,74.6,'Sequential gates: B = 2; LayerNorm → MLP → sigmoid',size=7.3,gid='gate_network')
    text(60,70.1,'1  Text energy → t2i → scale image spectrum',size=7.3,gid='step_t2i')
    text(60,65.6,'2  Updated image energy → i2t → scale text spectrum',size=7.3,gid='step_i2t')
    arrow('gates_to_inverse',(60,63),(60,60),color=BLUE)
    box('inverse_addnorm',10,52,100,8,fill=PALE_BLUE,color=BLUE)
    text(60,57.7,'irFFT1D / irFFT2D + input residuals',size=7.2,gid='inverse_residual')
    text(60,54.1,'AddNorm: LN → residual FFN(256→256→256) → LN',size=7.2,gid='addnorm_details')

    box('residual_container',120,49,48,51,fill=WHITE)
    text(144,96,'b  Residual FFN head',size=8.2,bold=True,gid='residual_title')
    text(144,90.8,'Separate modality blocks',size=7.2,gid='residual_independence')
    box('text_residual_ffn',128,76,36,11)
    text(146,83.0,'Text residual FFN',gid='text_ffn_title')
    text(146,79.0,'LN(T + FFN(T))',size=7.2,gid='text_ffn_expression')
    text(123.7,81.5,'T',gid='residual_T_port')
    arrow('text_to_text_ffn',(125.2,81.5),(128,81.5))
    box('image_residual_ffn',128,58,36,11)
    text(146,65.0,'Image residual FFN',gid='image_ffn_title')
    text(146,61.0,'LN(I + FFN(I))',size=7.2,gid='image_ffn_expression')
    text(123.7,63.5,'I',gid='residual_I_port')
    arrow('image_to_image_ffn',(125.2,63.5),(128,63.5))
    text(144,53.0,'FFN: 256 → 1024 → 256',size=7.2,gid='residual_width')

    # A chosen head emits two modality tensors, followed by the same readout design.
    arrow('spectral_to_common_readout',(60,49),(60,38))
    arrow('residual_to_common_readout',(144,49),(144,38))
    text(98.5,43.5,'One head per model',size=7.3,gid='alternative_head_note')
    box('common_readout',4,18,164,20,fill=PALE)
    text(44,33.4,'Text: reapply mask → masked max',gid='masked_pooling')
    text(128,33.4,'Image: max over 196 patches',gid='image_pooling')
    text(86,26.9,'Separate Linear(256,256) projections → addition',gid='additive_fusion')
    text(86,21.6,'MLP classifier: 256 → 1024 → 256 → 2 logits',gid='classifier')
    arrow('classifier_to_output',(86,18),(86,13.8))
    text(86,11.7,'Rumor / non-rumor classification',size=7.4,gid='binary_output')
    text(86,5.0,'Common inputs and readout design; learned weights are separate across models.',size=7.2,gid='weight_scope')

    fig.canvas.draw()
    # One schematic canvas; comparable head-container edges are checked separately.
    if require_matplotlib_panel_alignment is not None:
        require_matplotlib_panel_alignment(fig,json_out=HERE/'architecture.alignment.json',
                                          tolerance_pt=1.5,gutter_tolerance_pt=1.5,strict=True)
    else:
        (HERE/'architecture.alignment.json').write_text(json.dumps({'status':'not_applicable','reason':'One schematic canvas; container geometry and label intersections are checked locally.'}),encoding='utf-8')
    renderer=fig.canvas.get_renderer()
    # Deterministic final-size label audit: no pair of rendered label boxes may overlap.
    overlap=[]
    for i,t in enumerate(labels):
        assert t.get_fontsize()>=MIN_PT
        bb=t.get_window_extent(renderer)
        for other in labels[i+1:]:
            if bb.overlaps(other.get_window_extent(renderer)):
                overlap.append([t.get_gid(),other.get_gid()])
    assert not overlap,overlap
    fig.savefig(HERE/'architecture_comparison.pdf')
    fig.savefig(HERE/'architecture_comparison.svg')
    # Canonicalize equivalent SVG metadata for generic schematic auditing:
    # remove an unused external DTD and identity rotations; add explicit font-size
    # presentation attributes in user units matching Matplotlib's shorthand.
    # All geometry, displayed typography and live text remain unchanged.
    svg_path=HERE/'architecture_comparison.svg'
    svg=svg_path.read_text(encoding='utf-8')
    svg=re.sub(r'<!DOCTYPE[^>]*>\s*','',svg)
    svg=re.sub(r'\s+transform="rotate\(-?0(?:\.0*)? [^"]*\)"','',svg)
    def explicit_font(match):
        tag=match.group(0)
        # Matplotlib <=3.9 writes the CSS font shorthand; newer releases
        # emit separate font-weight and font-size properties.
        size=re.search(r'(?:font:\s*(?:\d{3}\s+)?|font-size:\s*)([\d.]+)px',tag)
        assert size is not None,tag
        return tag[:-1]+' font-size="'+size.group(1)+'">'
    svg=re.sub(r'<text\b[^>]*>',explicit_font,svg)
    svg_path.write_text(svg,encoding='utf-8')
    fig.savefig(HERE/'architecture_comparison.png',dpi=600)
    fig.savefig(HERE/'architecture_comparison.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
    fig.savefig(HERE/'architecture_preview.png',dpi=300)
    geometry={'width_mm':WIDTH_MM,'height_mm':HEIGHT_MM,'min_source_font_pt':min(t.get_fontsize() for t in labels),
              'font_family':'Arial (DejaVu Sans fallback)','text_elements':len(labels),
              'head_container_top_bottom_edges_identical':True,
              'unequal_head_width_reason':'Spectral operator detail requires a larger container; this is a schematic, not comparable plot areas.',
              'rendered_text_overlap_pairs':overlap,'boxes':boxes,'edges':edges}
    (HERE/'architecture_geometry.json').write_text(json.dumps(geometry,indent=2)+'\n',encoding='utf-8')
    plt.close(fig)
    print(json.dumps({k:geometry[k] for k in ['width_mm','height_mm','min_source_font_pt','text_elements','rendered_text_overlap_pairs']}))

if __name__=='__main__':build()
