# 五折集成算术口径增补

仅核查算术与分类结果，没有修改冻结协议、原预测或原结果，也没有重新推理模型。

原保存的 context 集成为 float64 累加器，逐折加上先以 float32 计算的 pred/5；本次 gate 集成为 np.stack(...).mean(0)，输出 float32。两者均可从对应五折数组精确重建，重建误差为 0。

两种集成概率的最大绝对差为 1.0430812835693359e-07，平均绝对差为 1.8118645423460557e-08；非逐元素相同的概率元素 1903/1996。998 行的 argmax 改变数为 0；全部混淆计数、Accuracy、Balanced Accuracy、两类 Precision/Recall/F1、macro Precision/F1 均完全一致。

五个 checkpoint/fold 的原概率重放最大差仍全部为 0。“原预测重放误差为 0”应限定为各 checkpoint/fold 以及 no-op hook 检查；集成部分应表述为“因算术精度不同存在极小概率差，分类与指标一致”，不能宣称两种集成概率逐元素同一。

完整逐项数值及输入 SHA256 见 ensemble_arithmetic_note.json。

数值来自原保存数组的直接比较。
