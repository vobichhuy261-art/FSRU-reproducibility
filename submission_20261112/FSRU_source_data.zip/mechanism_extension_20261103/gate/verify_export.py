"""Portable numeric audit: standard library; NumPy only for --bootstrap.
No imports from an original model/project, no weights or raw data required.
"""
import argparse,csv,datetime,hashlib,json,math,re,struct
from pathlib import Path

HERE=Path(__file__).resolve().parent
MODES=['dynamic','noop','source_mean','source_donor','cpu_dynamic','i2t_only_mean','t2i_only_mean']
def read(name):return json.loads((HERE/name).read_text(encoding='utf-8'))
def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()
def f32(x):return struct.unpack('f',struct.pack('f',x))[0]
def close(a,b,tol=1e-10):assert abs(a-b)<=tol*max(1,abs(a),abs(b)),(a,b)
def table(name):
    with (HERE/name).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def probability(row,mode):
    x=[float(row[mode+'_p0']),float(row[mode+'_p1'])]
    assert all(math.isfinite(v) and 0<=v<=1 for v in x)
    close(sum(x),1,3e-7)
    return x
def pred(row,mode):
    a,b=probability(row,mode);return int(b>a)
def matrix(rows,mode):
    c=[[0,0],[0,0]]
    for row in rows:c[int(row['label'])][pred(row,mode)]+=1
    return c
def scores(c):
    pr=[];re=[];f=[]
    for i in range(2):
        col=c[0][i]+c[1][i];row=c[i][0]+c[i][1]
        pr.append(c[i][i]/col if col else 0);re.append(c[i][i]/row if row else 0);f.append(2*c[i][i]/(row+col) if row+col else 0)
    n=sum(map(sum,c))
    return {'n':n,'accuracy':(c[0][0]+c[1][1])/n,'balanced_accuracy':sum(re)/2,'macro_precision':sum(pr)/2,'macro_f1':sum(f)/2,'class_precision':pr,'class_recall':re,'class_f1':f,'confusion':c}
def verify_metrics(rows,mode,record):
    actual=scores(matrix(rows,mode))
    for key,value in actual.items():
        if isinstance(value,list):
            if key=='confusion':assert value==record[key]
            else:
                for a,b in zip(value,record[key]):close(a,b,1e-12)
        else:close(value,record[key],1e-12)
    return actual
def quantiles(values):
    a=sorted(values);out=[]
    for q in [0,.25,.5,.75,1]:
        j=q*(len(a)-1);lo=int(j);hi=min(lo+1,len(a)-1);out.append(a[lo]+(a[hi]-a[lo])*(j-lo))
    return out
def check_vector(a,b,tol=1e-10):
    for x,y in zip(a,b):close(x,y,tol)
def std(values):
    mean=math.fsum(values)/len(values);return math.sqrt(math.fsum((x-mean)**2 for x in values)/len(values))

parser=argparse.ArgumentParser();parser.add_argument('--bootstrap',action='store_true');args=parser.parse_args()
manifest=read('manifest.json');root=HERE.resolve()
for entry in manifest['files']:
    path=(HERE/entry['path']).resolve();assert root in path.parents
    assert path.stat().st_size==entry['bytes'];assert digest(path)==entry['sha256'],entry['path']
protocol=read('protocol_anonymous.json');amendment=read('amendment_anonymous.json')
assert protocol['original_protocol_sha256']==manifest['original_protocol_sha256']
assert amendment['original_amendment_sha256']==manifest['original_amendment_sha256']
primary=read('results.json');directional=read('directional_results.json');params=read('gate_parameters.json');donors=read('source_donor_orders.json');partitions=read('partitions_anonymous.json')
source=table('source_predictions.csv');external=table('external_predictions.csv');external_fold=table('external_fold_predictions.csv')
assert len(source)==10203 and len(external)==998 and len(external_fold)==4990
for rows,prefix in [(source,'src'),(external,'ext')]:
    assert len({r['row_id'] for r in rows})==len(rows)
    for r in rows:
        assert re.fullmatch(prefix+r'_row_\d{6}',r['row_id'])
        assert re.fullmatch(prefix+r'_cmp_\d{4}',r['component_id'])
        assert r['label'] in ['0','1']
    for mode in MODES+['ffn_reference']:
        for r in rows:probability(r,mode)
    assert all(probability(r,'dynamic')==probability(r,'noop') for r in rows)
assert len({r['component_id'] for r in source})==355
assert len({r['component_id'] for r in external})==335
sourcemap={r['row_id']:r for r in source};externalmap={r['row_id']:r for r in external}
gate_counts={};gate_checks=[];fit_rows={};constant_by_fold={};scale=read('scale_diagnostics.json')['statistics']
for fold in range(5):
    pp=partitions[str(fold)];sets=[set(pp[k]) for k in ['fit','validation','test']]
    assert set.union(*sets)==set(sourcemap)
    assert not(sets[0]&sets[1] or sets[0]&sets[2] or sets[1]&sets[2])
    group_sets=[{sourcemap[x]['component_id'] for x in s} for s in sets]
    assert not(group_sets[0]&group_sets[1] or group_sets[0]&group_sets[2] or group_sets[1]&group_sets[2])
    assert sets[2]=={r['row_id'] for r in source if int(r['fold'])==fold}
    assert set(donors[str(fold)])==sets[0] and len(donors[str(fold)])==len(sets[0])
    combined=[]
    for split in ['fit','source_test','external']:
        rr=table('gates/fold'+str(fold)+'_'+split+'.csv');gate_counts[str(fold)+'_'+split]=len(rr)
        expected=sets[0] if split=='fit' else sets[2] if split=='source_test' else set(externalmap)
        assert {r['row_id'] for r in rr}==expected and len(rr)==len(expected)
        lookup=externalmap if split=='external' else sourcemap
        for row in rr:
            assert row['component_id']==lookup[row['row_id']]['component_id'] and int(row['fold'])==fold and row['split']==split
        if split=='fit':fit_rows[fold]=[r['row_id'] for r in rr]
        for d in ['t2i','i2t']:
            energy=[[float(x[d+'_energy'+str(j)]) for j in range(2)] for x in rr]
            gates=[[float(x[d+'_gate'+str(j)]) for j in range(2)] for x in rr]
            affine=[[float(x[d+'_ln'+str(j)]) for j in range(2)] for x in rr]
            par=params[str(fold)][d];eps=par['eps'];delta=[(x[0]-x[1])/2 for x in energy];a=[x/math.sqrt(x*x+eps) for x in delta]
            expected_ln=[[a[i]*par['layernorm_weight'][0]+par['layernorm_bias'][0],-a[i]*par['layernorm_weight'][1]+par['layernorm_bias'][1]] for i in range(len(rr))]
            error=max(abs(affine[i][j]-expected_ln[i][j]) for i in range(len(rr)) for j in range(2));assert error<1e-6
            recorded=next(x for x in primary['gate_statistics'] if x['fold']==fold and x['split']==split and x['direction']==d)
            close(sum(abs(x)>=.99 for x in a)/len(a),recorded['preaffine_saturation_abs_a_ge_0_99'],1e-12)
            check_vector(quantiles([abs(x) for x in a]),recorded['abs_a_quantiles'])
            check_vector([std([x[j] for x in gates]) for j in range(2)],recorded['gate_sd'])
            for j in range(2):
                check_vector(quantiles([x[j] for x in gates]),[z[j] for z in recorded['gate_quantiles']])
                check_vector(quantiles([x[j] for x in energy]),[z[j] for z in recorded['energy_quantiles']])
            expected_scale=next(x for x in scale if x['fold']==fold and x['split']==split and x['direction']==d)
            check_vector(quantiles([abs(x)/math.sqrt(eps) for x in delta]),expected_scale['abs_delta_over_sqrt_eps_quantiles'])
            if split=='fit':
                means=[f32(math.fsum(x[j] for x in gates)/len(gates)) for j in range(2)]
                assert means==par['mean_gate']
            gate_checks.append({'fold':fold,'split':split,'direction':d,'n':len(rr),'analytic_ln_max_error':error,'unique_gate_rows':len({tuple(x) for x in gates})})
            if d=='i2t':combined.extend(map(tuple,gates))
    constant_by_fold[str(fold)]=len(set(combined));assert len(set(combined))==1
    ss=[r for r in source if int(r['fold'])==fold]
    ee=[r for r in external_fold if int(r['fold'])==fold]
    assert len(ee)==len(external) and {r['row_id'] for r in ee}==set(externalmap)
    for target in [ss,ee]:
        for j,row in enumerate(target):assert row['donor_row_id']==donors[str(fold)][j%len(donors[str(fold)])]
    for row in ee:
        base=externalmap[row['row_id']];assert row['label']==base['label'] and row['component_id']==base['component_id']

ensemble_error=0
foldmap={(int(r['fold']),r['row_id']):r for r in external_fold}
for row in external:
    for mode in MODES+['ffn_reference']:
        for j in range(2):
            total=f32(0)
            for fold in range(5):total=f32(total+float(foldmap[fold,row['row_id']][mode+'_p'+str(j)]))
            expected=f32(total/5);error=abs(expected-float(row[mode+'_p'+str(j)]));ensemble_error=max(ensemble_error,error);assert error<2e-7
metrics_verified=0
for name,rows in [('source_oof',source),('external_ensemble',external)]:
    for mode in ['dynamic','noop','source_mean','source_donor']:
        verify_metrics(rows,mode,primary['results'][name]['metrics'][mode]);metrics_verified+=1
    for mode in ['cpu_dynamic','i2t_only_mean','t2i_only_mean']:
        verify_metrics(rows,mode,directional['results'][name]['metrics'][mode]);metrics_verified+=1
    verify_metrics(rows,'ffn_reference',primary['results']['ffn_reference'][name]);metrics_verified+=1
    for mode in ['source_mean','source_donor']:
        changes=sum(pred(r,mode)!=pred(r,'dynamic') for r in rows)
        assert changes==primary['results'][name]['effects'][mode]['label_change_count']
    assert all(pred(r,'i2t_only_mean')==pred(r,'cpu_dynamic') for r in rows)

bootstrap_checks=[]
if args.bootstrap:
    import numpy as np
    for fold in range(5):
        order=np.random.default_rng(20261103+fold).permutation(len(fit_rows[fold]))
        assert [fit_rows[fold][i] for i in order]==donors[str(fold)]
    def ff(c):
        den=c.sum(0)+c.sum(1);return float(np.mean(np.divide(2*np.diag(c),den,out=np.zeros(2),where=den!=0)))
    for name,rows in [('source_oof',source),('external_ensemble',external)]:
        groups=sorted({r['component_id'] for r in rows});gi={g:i for i,g in enumerate(groups)}
        blocks={m:np.zeros((len(groups),2,2),np.int64) for m in MODES}
        for row in rows:
            for m in MODES:blocks[m][gi[row['component_id']],int(row['label']),pred(row,m)]+=1
        for base,mode,reference in [('dynamic',m,primary['results'][name]['effects'][m]['ci95']) for m in ['noop','source_mean','source_donor']]+[('cpu_dynamic',m,directional['results'][name]['effects'][m]['ci95']) for m in ['i2t_only_mean','t2i_only_mean']]:
            rng=np.random.default_rng(20261103);diff=[]
            for _ in range(2000):
                ix=rng.integers(0,len(groups),len(groups));diff.append(ff(blocks[mode][ix].sum(0))-ff(blocks[base][ix].sum(0)))
            actual=np.quantile(diff,[.025,.975]).tolist();check_vector(actual,reference,1e-12)
            bootstrap_checks.append({'split':name,'mode':mode,'ci95':actual})
verification={'status':'passed','verified_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_sha256':digest(HERE/'manifest.json'),'original_protocol_sha256':manifest['original_protocol_sha256'],'standard_library_checks':True,'neural_inference_repeated_in_export':False,'source_rows':len(source),'external_rows':len(external),'external_fold_rows':len(external_fold),'gate_row_counts':gate_counts,'gate_checks':gate_checks,'joint_original_i2t_unique_rows_per_fold':constant_by_fold,'metric_sets_verified':metrics_verified,'ensemble_max_numeric_error':ensemble_error,'numpy_bootstrap_requested':args.bootstrap,'bootstrap_checks':bootstrap_checks,'inference_scope':'Original GPU full replay; primary independent CPU fixed sample 120 row evaluations; directional CPU full 15193 observations per mode, 45579 across three modes. Inference provenance is included, not re-executed from this export.'}
(HERE/'export_verification.json').write_text(json.dumps(verification,ensure_ascii=False,indent=2),encoding='utf-8')
print('PASSED: anonymous numeric export independently verified; bootstrap='+str(args.bootstrap))
