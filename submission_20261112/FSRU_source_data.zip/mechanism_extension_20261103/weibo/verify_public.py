"""Independent anonymous export verification; stdlib default, optional NumPy.

No imports from training, summarization, export or original bootstrap programs.
"""
import argparse
import csv
import hashlib
import json
import math
import statistics
from pathlib import Path

ROOT = Path(__file__).resolve().parent
METRICS = ['accuracy', 'nonrumor_precision', 'rumor_precision', 'nonrumor_recall',
           'rumor_recall', 'nonrumor_f1', 'rumor_f1', 'macro_f1', 'macro_precision']
CONTRASTS = ['contextual_spectral_minus_residual', 'static_spectral_minus_residual',
             'contextual_minus_static_spectral', 'contextual_minus_static_residual',
             'interaction_contextual_block_minus_static_block']


def read(name):
    return json.loads((ROOT / name).read_text(encoding='utf-8'))


def csvread(name):
    with open(ROOT / name, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def close(a, b, context=''):
    assert math.isfinite(float(a)) and math.isfinite(float(b)), context
    assert abs(float(a) - float(b)) < 1e-12, (context, a, b)


def metrics(y, pred):
    n = len(y)
    assert n and len(pred) == n
    cm = [[0, 0], [0, 0]]
    for t, p in zip(y, pred):
        cm[t][p] += 1
    div = lambda a, b: a / b if b else 0.0
    pp = [div(cm[k][k], cm[0][k] + cm[1][k]) for k in range(2)]
    rr = [div(cm[k][k], sum(cm[k])) for k in range(2)]
    ff = [div(2 * cm[k][k], 2 * cm[k][k] + cm[1-k][k] + cm[k][1-k]) for k in range(2)]
    return dict(zip(METRICS, [(cm[0][0] + cm[1][1]) / n, pp[0], pp[1], rr[0], rr[1],
                              ff[0], ff[1], sum(ff) / 2, sum(pp) / 2]))


def check_desc(values, expected, context):
    assert expected['n'] == len(values), context
    close(statistics.mean(values), expected['mean'], context + ' mean')
    close(statistics.stdev(values), expected['sd'], context + ' SD')
    close(min(values), expected['min'], context + ' min')
    close(max(values), expected['max'], context + ' max')


def verify(bootstrap=False):
    manifest = read('manifest.json')
    actual = {p.name for p in ROOT.iterdir() if p.is_file()}
    assert actual - set(manifest['exclusions']) == set(manifest['files'])
    for name, digest in manifest['files'].items():
        assert hashlib.sha256((ROOT / name).read_bytes()).hexdigest() == digest, name
    mapping = {a: tuple(v) for a, v in read('arm_mapping.json')['mapping'].items()}
    inverse = {v: a for a, v in mapping.items()}
    seeds = read('arm_mapping.json')['seeds']
    rows = csvread('anonymous_predictions.csv')
    assert len(rows) == manifest['rows'] == 7723
    groups = sorted({r['component_code'] for r in rows})
    assert len(groups) == manifest['components'] == 7220
    assert [r['row_code'] for r in rows] == [f'R{i:05d}' for i in range(len(rows))]
    assert groups == [f'G{i:05d}' for i in range(len(groups))]
    y = [int(r['label']) for r in rows]
    assert set(y) == {0, 1}
    predictions = {}
    for arm in sorted(mapping):
        for seed in seeds:
            pp = []
            for row in rows:
                a, b = [float(row[f'{arm}_s{seed}_p{k}']) for k in range(2)]
                assert math.isfinite(a) and math.isfinite(b) and 0 <= a <= 1 and 0 <= b <= 1
                assert abs(a+b-1) < 1e-6
                pp.append(int(b > a))
            predictions[arm, seed] = pp
    partition = csvread('partitions.csv')
    summary = read('summary.json')
    assert summary['status'] == 'all_60_verified'
    for fold in range(5):
        cg, count = {}, {role: 0 for role in ['fit', 'valid', 'test']}
        groupcount = {role: set() for role in count}
        for row in rows:
            role = row[f'fold{fold}_role']
            assert role in count
            assert (int(row['outer_fold']) == fold) == (role == 'test')
            g = row['component_code']
            assert cg.setdefault(g, role) == role
            count[role] += 1
            groupcount[role].add(g)
        p = next(r for r in partition if int(r['fold']) == fold)
        for role in count:
            assert count[role] == int(p[role])
            assert len(groupcount[role]) == int(p[role+'_groups'])
        assert int(p['group_overlap']) == 0
        for key, value in p.items():
            assert int(value) == summary['partitions'][fold][key]
    runs, oofs, seedmeans = {}, {}, {}
    records = csvread('run_metrics.csv')
    assert len(records) == 60
    for record in records:
        rep, head = record['representation'], record['head']
        arm = inverse[rep, head]
        seed, fold = int(record['seed']), int(record['fold'])
        idx = [i for i, row in enumerate(rows) if int(row['outer_fold']) == fold]
        m = metrics([y[i] for i in idx], [predictions[arm, seed][i] for i in idx])
        for key in METRICS:
            close(m[key], record[key], f'{arm}/{seed}/{fold}/{key}')
        assert (arm, seed, fold) not in runs
        runs[arm, seed, fold] = m
        assert int(record['parameters']) == summary['cell_summary'][rep+'__'+head]['parameters']
    assert len(runs) == 60
    for arm in mapping:
        for seed in seeds:
            oofs[arm, seed] = metrics(y, predictions[arm, seed])
            seedmeans[arm, seed] = {key: statistics.mean(runs[arm, seed, f][key] for f in range(5)) for key in METRICS}
    for file, expected in [('seed_oof_metrics.csv', oofs), ('seed_fivefold_mean_metrics.csv', seedmeans)]:
        rr = csvread(file)
        assert len(rr) == 12
        seen = set()
        for record in rr:
            arm = inverse[record['representation'], record['head']]
            seed = int(record['seed'])
            assert (arm, seed) not in seen
            seen.add((arm, seed))
            for key in METRICS:
                close(expected[arm, seed][key], record[key], file+'/'+key)
    for arm, (rep, head) in mapping.items():
        cell = summary['cell_summary'][rep+'__'+head]
        for key in METRICS:
            check_desc([runs[arm, s, f][key] for s in seeds for f in range(5)], cell['fold_run_metrics'][key], arm+key+' runs')
            check_desc([oofs[arm, s][key] for s in seeds], cell['seed_oof_metrics'][key], arm+key+' OOF')
            check_desc([seedmeans[arm, s][key] for s in seeds], cell['seed_fivefoldmean_metrics'][key], arm+key+' seedmeans')
            for seed in seeds:
                close(seedmeans[arm, seed][key], cell['seed_specific_fivefoldmean_metrics'][str(seed)][key])
    for kind, source in [('fold', 'fold_paired_effects.csv'), ('seed_oof', 'seed_oof_paired_effects.csv')]:
        values = csvread(source)
        assert len(values) == (5 if kind == 'fold' else 3)
        for key in METRICS:
            effects = {}
            for rep in ['contextual', 'static_lookup']:
                left, right = inverse[rep, 'context'], inverse[rep, 'context_ffn']
                expected = ([statistics.mean(runs[left,s,f][key]-runs[right,s,f][key] for s in seeds) for f in range(5)]
                            if kind == 'fold' else [oofs[left,s][key]-oofs[right,s][key] for s in seeds])
                effects[rep] = expected
                col = rep+'_'+key+'_spectral_minus_residual'
                for record, val in zip(values, expected):
                    close(record[col], val, col)
                check_desc(expected, summary[kind+'_effects'][col], col)
            col = key+'_interaction_contextual_minus_static'
            vals = [a-b for a,b in zip(effects['contextual'], effects['static_lookup'])]
            for record, val in zip(values, vals):
                close(record[col], val, col)
            check_desc(vals, summary[kind+'_effects'][col], col)
    histories = csvread('inner_validation_history.csv')
    audit = csvread('checkpoint_replay_audit.csv')
    assert len(audit) == 60
    maximum = 0.0
    for a in audit:
        h = [r for r in histories if all(r[k] == a[k] for k in ['arm','seed','fold'])]
        assert [int(r['epoch']) for r in h] == list(range(1,len(h)+1))
        best = max(h, key=lambda r: float(r['inner_macro_f1']))
        assert int(best['epoch']) == int(a['selected_epoch'])
        close(best['inner_macro_f1'], a['selected_inner_macro_f1'])
        close(a['replay_inner_macro_f1'], a['selected_inner_macro_f1'])
        assert int(a['replay_label_changes']) == 0
        delta, tol = float(a['replay_probability_max_abs_difference']), float(a['probability_tolerance'])
        assert 0 <= delta <= tol <= 1e-4
        maximum = max(maximum, delta)
    result = {'status': 'passed', 'rows': len(rows), 'candidate_components': len(groups),
              'fits': len(runs), 'seeds_per_arm': len(seeds), 'seed_oof_records': len(oofs),
              'role_group_overlap': 0, 'all_60_metrics_and_seed_summaries_replayed': True,
              'all_inner_checkpoint_selection_histories_checked': True,
              'maximum_reported_checkpoint_replay_probability_error': maximum,
              'reported_checkpoint_replay_label_changes': 0, 'bootstrap_replayed': False,
              'boundary': 'Independent arithmetic implementation, not an independent investigator, new dataset, or full weight replay.'}
    if bootstrap:
        import numpy as np
        bs = read('bootstrap_summary.json')
        assert bs['replicates'] == 2000 and bs['rng_seed'] == 20261103
        ri = np.asarray([int(r['component_code'][1:]) for r in rows],dtype=int)
        labels = np.asarray(y, dtype=np.uint8)
        order = [inverse['contextual','context'], inverse['contextual','context_ffn'],
                 inverse['static_lookup','context'], inverse['static_lookup','context_ffn']]
        # Deliberately uses raw row weights rather than grouped confusion matrices.
        codes = [[2*labels + np.asarray(predictions[a,s],dtype=np.uint8) for s in seeds] for a in order]
        multiplicities = np.random.default_rng(20261103).multinomial(len(groups),np.full(len(groups),1/len(groups)),size=2000)
        draws = []
        for counts in multiplicities:
            weights = counts[ri].astype(float)
            arms = []
            for arm in codes:
                scores=[]
                for code in arm:
                    cm = np.bincount(code,weights=weights,minlength=4).reshape(2,2)
                    scores.append(sum(2*cm[k,k]/(2*cm[k,k]+cm[1-k,k]+cm[k,1-k])
                                      if (2*cm[k,k]+cm[1-k,k]+cm[k,1-k]) else 0.0 for k in [0,1])/2)
                arms.append(sum(scores)/len(scores))
            a,b,c,d=arms
            draws.append([a-b,c-d,a-c,b-d,(a-b)-(c-d)])
        draws=np.asarray(draws)
        stored=csvread('bootstrap_contrast_draws.csv')
        assert len(stored)==2000
        expected=np.asarray([[float(r[k]) for k in CONTRASTS] for r in stored])
        maxerr=float(np.abs(draws-expected).max())
        assert maxerr<1e-12
        point=[statistics.mean(oofs[a,s]['macro_f1'] for s in seeds) for a in order]
        a,b,c,d=point
        pointcontrasts=[a-b,c-d,a-c,b-d,(a-b)-(c-d)]
        for i,key in enumerate(CONTRASTS):
            target=bs['contrasts'][key]
            close(pointcontrasts[i],target['point'],key+' point')
            close(float(np.quantile(draws[:,i],.025)),target['percentile95_low'],key+' low')
            close(float(np.quantile(draws[:,i],.975)),target['percentile95_high'],key+' high')
            close(float(np.std(draws[:,i],ddof=1)),target['bootstrap_sd'],key+' sd')
        result.update(bootstrap_replayed=True,replicates=2000,paired_contrasts=5,
                      bootstrap_max_abs_difference=maxerr,numpy_version=np.__version__)
    name = 'verification_bootstrap.json' if bootstrap else 'verification.json'
    (ROOT / name).write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(result,indent=2))
    return result


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--bootstrap',action='store_true')
    args=parser.parse_args()
    verify(args.bootstrap)
