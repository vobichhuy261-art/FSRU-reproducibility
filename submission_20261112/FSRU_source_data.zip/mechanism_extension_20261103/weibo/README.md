# Anonymous Weibo representation–block evidence

This package covers four conditions, five outer folds and three initialization seeds: all 60 fixed fits. It contains 7,723 rows in 7,220 operational candidate components. Models and all per-run probabilities were retained, without selecting favorable cells.

Run `python verify_public.py` using Python 3.9 or later for standard-library checks of hashes, rows, role/component isolation, all 60 confusion-derived metric records, all 12 seed-specific OOF and fold-mean records, summary statistics, and checkpoint selection from the complete retained inner-validation histories.

Run `python verify_public.py --bootstrap` with NumPy (original computation: 1.26.2) to independently rebuild all 2,000 bootstrap draws from raw row weights and all five paired contrasts. The multinomial RNG seed is 20261103. Lexicographic anonymous component order preserves the order used by the frozen computation. All four arms and three seeds share each component multiplicity. No model is retrained.

`anonymous_predictions.csv` includes each row's binary label, five fit/valid/test roles, outer fold, anonymous component code and both original class probabilities for every arm/seed. Prediction is argmax, with exact ties assigned to class 0. The `arm_mapping.json` file identifies the scientific configurations. Labels A–D are only computational anonymization; the public package is not blinded to semantic arm names. Row/component codes are pseudonyms and are not a formal privacy guarantee.

The main table's mean and sample SD are calculated from the three seed-specific five-fold means. Bootstrap contrasts use the mean of three seed-specific pooled-OOF macro-F1 scores, a different estimand. Components are operational duplicate candidates rather than certified independent events. Five contrasts have pointwise, unadjusted percentile intervals conditional on the fixed models. Earlier development outcomes had been viewed, and the bootstrap amendment was frozen at 8/60 completed fits. This is not new untouched confirmation, retraining uncertainty, or equivalence testing.

The same-head static/contextual initial states are identical at each seed. Across heads, downstream initialization can differ because the original constructors consume different random draws. Static input is pretrained embedding lookup from the same tokenizer/checkpoint, not Word2Vec or an unpretrained control. The heads also differ in parameter count and gating, so this design does not isolate FFT alone.

One selected checkpoint initially failed a 1e-6 replay probability tolerance. Three same-device reloads showed a maximum 5.364418e-6 difference from stored probabilities with unchanged predictions and metrics. The tolerance was documented as 1e-4 plus an explicit requirement for identical labels. The existing fit was sealed without retraining or replacing original predictions. Original failure and hashes remain in the diagnostic. Bitwise inference reproducibility is not claimed; original training logits were not retained. All 60 final replay differences appear in `checkpoint_replay_audit.csv`.

The archive contains no raw captions/images, original sample/article IDs, input embeddings, binary weights, or inherited model source. It supports arithmetic result replay, not end-to-end retraining. SHA-256 checks protect file consistency, not scientific truth. Verification receipts are generated locally and excluded from the immutable manifest.

Numerical results originate in retained experiment outputs.
