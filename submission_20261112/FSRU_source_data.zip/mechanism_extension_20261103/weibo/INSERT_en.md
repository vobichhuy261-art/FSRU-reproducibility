# Evidence-bound manuscript insert: Weibo representation–block comparison

We extended the original contextual-versus-residual comparison to the same candidate-component-constrained Weibo partitions. The factorial comprised two frozen text-input configurations (contextual tokens and input word-embedding lookup from the identical Chinese RoBERTa checkpoint/tokenizer), two original heads (the spectral block with cross-modal band gating and residual FFNs), five outer folds, and three initialization seeds (60 fixed runs). All inputs were 768-dimensional with the same 126-token budget, compacted validity masks, image features, train/validation/test roles, downstream wrapper, and optimization/checkpoint rules. Static lookup excluded the contextual encoder and the BERT positional/type embeddings and embedding LayerNorm; both conditions retained the identical trainable positional encoding in the downstream head. This intervention compares input configurations and does not isolate pretraining or reproduce the Word2Vec architecture.

Training used the unchanged cross-entropy plus the two original contrastive losses (weights 0.2 each), AdamW (learning rate 0.001; weight decay 0.01), batch size 32, at most 50 epochs, and patience 10. The earliest checkpoint attaining the largest inner-validation macro-F1 was retained. The five folds were shared across all conditions, and outer labels and VERITE were excluded from fitting and checkpoint selection. Candidate-component isolation does not establish complete event isolation. All selected weights were reloaded, their probabilities replayed, and class metrics independently recomputed from confusion counts.

For consistency with the main Twitter reporting unit, each seed was first averaged over its five outer folds; the following values report the mean and sample SD across the three resulting seed means:

- Contextual + spectral: macro-F1 93.231 ± 0.244%; rumor F1 93.667 ± 0.188%; nonrumor F1 92.795 ± 0.304%; macro precision 93.278 ± 0.217%.
- Contextual + residual FFN: macro-F1 92.864 ± 0.113%; rumor F1 93.314 ± 0.106%; nonrumor F1 92.415 ± 0.131%; macro precision 92.905 ± 0.095%.
- Static lookup + spectral: macro-F1 90.623 ± 0.311%; rumor F1 91.183 ± 0.252%; nonrumor F1 90.064 ± 0.369%; macro precision 90.670 ± 0.214%.
- Static lookup + residual FFN: macro-F1 89.755 ± 0.161%; rumor F1 90.286 ± 0.260%; nonrumor F1 89.225 ± 0.078%; macro precision 89.790 ± 0.149%.

An exploratory analysis amendment was recorded after 8 of 60 individual runs were available and before aggregation of the full study. We used 2,000 paired candidate-component bootstrap replicates (RNG seed 20261103), sharing each component multiplicity across all four conditions and all three seeds. The bootstrap estimand is the mean of the three seed-specific pooled-OOF macro-F1 scores; it differs from the fold-mean estimand above. The following five contrasts were fixed in the amendment and use unadjusted, pointwise 95% percentile intervals:

- contextual_spectral_minus_residual: +0.368 percentage points [+0.015, +0.684].
- static_spectral_minus_residual: +0.867 percentage points [+0.481, +1.270].
- contextual_minus_static_spectral: +2.608 percentage points [+2.096, +3.113].
- contextual_minus_static_residual: +3.108 percentage points [+2.593, +3.653].
- interaction_contextual_block_minus_static_block: -0.500 percentage points [-1.042, +0.001].

These intervals condition on the trained models and observed candidate components; models were not refit within bootstrap replicates. They do not include all training-sample uncertainty, apply no multiplicity correction, and support no equivalence or new confirmatory claim. Folds share training observations and seeds are repeated initializations, so neither 15 runs nor five folds constitute independent datasets. The complete original block comparison also differs in parameter count and cross-modal gating, precluding attribution solely to FFT. This study supplements mechanism evidence on previously inspected development data and must be interpreted alongside the Twitter controls, external fixed-protocol findings, and gate audit.

The same-head representation intervention uses tensor-identical initial states at each seed. Across different heads, the original construction order gives the input projections identical initial values but consumes different random draws before the mix/classifier layers; the latter are therefore not tensor-matched across heads. This initialization boundary is retained and disclosed rather than repaired after observing outcomes.

An engineering replay check initially stopped at a 5.364418e-6 probability difference for static spectral fold 2, seed 31, exceeding the original 1e-6 technical tolerance. Three same-device reloads preserved all original argmax decisions and confusion-derived metrics. The existing checkpoint and original probabilities were retained without retraining; a logged 1e-4 probability tolerance with exact argmax agreement was then used. This repair changes no training, checkpoint-selection or scientific endpoint and does not establish bitwise probability reproducibility.

Numerical results were obtained from retained model outputs and independently recomputed.
