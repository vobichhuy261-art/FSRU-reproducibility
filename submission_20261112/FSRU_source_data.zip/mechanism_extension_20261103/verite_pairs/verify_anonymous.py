"""Independently verify anonymous exports. No original captions, images or model needed.

Python standard library checks all point results and interval calculations from saved
bootstrap draws. --replay-bootstrap additionally requires NumPy and replays draws.
"""
from pathlib import Path
import csv, json, math, sys, hashlib, statistics

P=Path(__file__).resolve().parent
def read(name):
    with (P/name).open(encoding='utf-8',newline='') as f:return list(csv.DictReader(f))
def check(a,b):
    assert math.isclose(float(a),float(b),abs_tol=1e-12,rel_tol=1e-12),(a,b)
def q(values, fraction):
    a=sorted(values);i=(len(a)-1)*fraction;l=math.floor(i);h=math.ceil(i)
    return a[l]+(a[h]-a[l])*(i-l)
def stats(values, target):
    assert len(values)==target['n']
    for key,val in [('mean',statistics.mean(values)),('median',statistics.median(values)),
                    ('q25',q(values,.25)),('q75',q(values,.75)),('min',min(values)),('max',max(values))]:check(val,target[key])
def global_auc(items):
    # Rank-sum algorithm, independent of pairwise difference matrix used by analysis.
    items=sorted(items,key=lambda x:x[0]);n0=sum(y==0 for _,y in items);n1=len(items)-n0
    numerator=0;below0=0;i=0
    while i<len(items):
        j=i+1
        while j<len(items) and items[j][0]==items[i][0]:j+=1
        z=sum(y==0 for _,y in items[i:j]);o=j-i-z
        numerator+=o*(below0+.5*z);below0+=z;i=j
    return numerator/(n0*n1)

def main():
    rows=read('anonymous_rows.csv');pairs=read('anonymous_pairs.csv');boot=read('conditional_bootstrap.csv')
    result=json.loads((P/'results.json').read_text(encoding='utf-8'))
    proto=json.loads((P/'protocol.json').read_text(encoding='utf-8'))
    assert len(rows)==998 and len(boot)==2000
    assert len({r['article'] for r in rows})==337 and len({r['component'] for r in rows})==335
    assert all(int(r['row'])==i for i,r in enumerate(rows))
    result_hash=hashlib.sha256((P/'protocol.json').read_bytes()).hexdigest()
    assert result_hash==result['protocol_sha256']
    for m in ['spectral','residual']:
        target=result['models'][m];cm=[[0,0],[0,0]];ss=[];bs=[];nll=[]
        for r in rows:
            s=float(r[m+'_misinformation_probability']);y=int(r['label']);pred=int(s>.5)
            ss.append((s,y));cm[y][pred]+=1;bs.append((s-y)**2)
            s=max(1e-7,min(1-1e-7,s));nll.append(-math.log(s if y else 1-s))
        assert cm==target['confusion_matrix_true_rows_pred_columns']
        check(global_auc(ss),target['global_binary_auc'])
        check((cm[0][0]+cm[1][1])/len(rows),target['accuracy'])
        check(statistics.mean(2*cm[a][a]/(2*cm[a][a]+cm[a][1-a]+cm[1-a][a]) for a in [0,1]),target['macro_f1'])
        check(statistics.mean(bs),target['brier']);check(statistics.mean(nll),target['nll'])
        for c in ['true','miscaptioned','out-of-context']:
            stats([float(r[m+'_misinformation_probability']) for r in rows if r['original_class']==c],target['class_scores'][c])
    for rel in ['same_image_different_caption','same_caption_different_image']:
        pp=[p for p in pairs if p['relation']==rel];target=result['relations'][rel]
        assert len(pp)==target['pairs']==proto['pair_denominators'][rel]['valid_pairs']
        assert len({p['component'] for p in pp})==target['represented_components']
        for m in ['spectral','residual']:
            t=target['models'][m];margins=[];logs=[];credits=[];cats={k:0 for k in t['fixed_argmax_pair_counts']}
            correct_pos=correct_neg=0
            for p in pp:
                a=rows[int(p['true_row'])];b=rows[int(p['false_row'])]
                assert a['label']=='0' and b['label']=='1'
                assert a['article']==b['article']==p['article']
                assert a['component']==b['component']==p['component']
                s0=float(a[m+'_misinformation_probability']);s1=float(b[m+'_misinformation_probability'])
                check(s0,p[m+'_true_score']);check(s1,p[m+'_false_score'])
                d=s1-s0;credit=(1 if d>0 else .5 if d==0 else 0)
                check(d,p[m+'_margin']);check(credit,p[m+'_ranking_credit'])
                margins.append(d);credits.append(credit)
                s0=max(1e-7,min(1-1e-7,s0));s1=max(1e-7,min(1-1e-7,s1))
                logs.append(math.log(s1/(1-s1))-math.log(s0/(1-s0)))
                a_positive=float(a[m+'_misinformation_probability'])>.5;b_positive=float(b[m+'_misinformation_probability'])>.5
                cat=('both_predicted_misinformation' if a_positive and b_positive else
                     'both_predicted_true' if not a_positive and not b_positive else
                     'both_correct' if not a_positive and b_positive else 'both_wrong')
                cats[cat]+=1
                correct_pos+=int(d>0 and a_positive and b_positive)
                correct_neg+=int(d>0 and not a_positive and not b_positive)
            assert cats==t['fixed_argmax_pair_counts']
            assert correct_pos==t['correct_rank_but_both_predicted_misinformation']
            assert correct_neg==t['correct_rank_but_both_predicted_true']
            assert sum(d>0 for d in margins)==t['wins'] and sum(d==0 for d in margins)==t['ties'] and sum(d<0 for d in margins)==t['losses']
            stats(margins,t['probability_margin']);stats(logs,t['logit_margin']);check(statistics.mean(credits),t['paired_discrimination'])
            for kind,key in [('ranking','paired_discrimination_ci95'),('margin','probability_mean_margin_ci95')]:
                values=[float(b[rel+'__'+m+'__'+kind]) for b in boot]
                for actual,expected in zip([q(values,.025),q(values,.975)],t[key]):check(actual,expected)
        for kind,key in [('ranking','paired_discrimination_ci95'),('margin','mean_probability_margin_ci95')]:
            values=[float(b[rel+'__spectral__'+kind])-float(b[rel+'__residual__'+kind]) for b in boot]
            for actual,expected in zip([q(values,.025),q(values,.975)],target['spectral_minus_residual'][key]):check(actual,expected)
    replay=False
    if '--replay-bootstrap' in sys.argv:
        try:import numpy as np
        except ImportError:
            # Optional nearby environment discovery; no embedded private paths.
            for ancestor in P.parents:
                candidate=ancestor/'.venv/Lib/site-packages'
                if candidate.is_dir():sys.path.insert(0,str(candidate))
            import numpy as np
        components=sorted({r['component'] for r in rows});cm={c:i for i,c in enumerate(components)}
        rng=np.random.default_rng(20261103)
        draws=rng.integers(0,len(components),size=(2000,len(components)))
        # Aggregate per component first, unlike analysis's per-pair weight matrix.
        for rel in ['same_image_different_caption','same_caption_different_image']:
            pp=[p for p in pairs if p['relation']==rel];n=np.zeros(len(components))
            sums={m:{kind:np.zeros(len(components)) for kind in ['ranking','margin']} for m in ['spectral','residual']}
            for p in pp:
                g=cm[p['component']];n[g]+=1
                for m in sums:
                    sums[m]['ranking'][g]+=float(p[m+'_ranking_credit']);sums[m]['margin'][g]+=float(p[m+'_margin'])
            for j,d in enumerate(draws):
                for m in sums:
                    for kind in sums[m]:check(sums[m][kind][d].sum()/n[d].sum(),boot[j][rel+'__'+m+'__'+kind])
        replay=True
    verification={'passed':True,'anonymous_rows':len(rows),'anonymous_pairs':len(pairs),
                  'standard_library_point_estimates_independently_recomputed':True,
                  'all_saved_bootstrap_interval_percentiles_verified':True,'all_2000_component_draws_replayed':replay,
                  'no_media_or_caption_needed':True,'threshold':0.5,'ties_predicted_class':0,
                  'analysis_scope':'Anonymous fixed-prediction diagnostic verification; source identity checks are in frozen protocol.'}
    (P/'verification.json').write_text(json.dumps(verification,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(verification))

if __name__=='__main__':main()
