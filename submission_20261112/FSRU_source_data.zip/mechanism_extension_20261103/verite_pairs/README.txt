Anonymous fixed-prediction VERITE diagnostic package

No raw captions, images, original article IDs, source indices, access tokens or private absolute paths are included.
The two relation-specific pair sets share true rows; do not treat their 661 comparisons as independent.
Python standard library: python verify_anonymous.py
All 2000 bootstrap draws: python verify_anonymous.py --replay-bootstrap
Bootstrap replay additionally requires NumPy (original numerical environment: NumPy 1.26.2).
Source predictions and identities were frozen before calculating these new pair diagnostics, but prior global benchmark outcomes were known. This is not an untouched independent confirmation.
protocol.json is a documented privacy-redacted copy, linked to the unmodified original frozen protocol by SHA256. The results link to this copy for detached verification.
run_analysis.py and the private source-identity audit remain in the local research directory, outside this anonymous package.
