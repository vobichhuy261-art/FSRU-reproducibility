import json
import numpy as np
from metrics import evaluate
with np.load("predictions.npz") as p:
    target=json.load(open("result.json", encoding="utf8"))
    y,g,b,r=(p[k] for k in ("labels","groups","spectral","residual"))
    assert evaluate(y,g,b,r)==target["comparison"]
    for k in ("i2t","t2i","both"):
        assert (p[k].argmax(-1)!=b.argmax(-1)).sum(1).tolist()==target["interventions"][k]["flips_per_seed"]
        assert evaluate(y,g,p[k],b)==target["interventions"][k]["comparison_to_dynamic"]
    keep=~p["event_holdout"]
    expected=json.load(open("event_sensitivity_result.json", encoding="utf8"))
    assert evaluate(y[keep],g[keep],b[:,keep],r[:,keep])==expected["comparison"]
print("FineFake numerical replay passed")
