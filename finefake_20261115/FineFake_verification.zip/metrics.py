"""Evaluate paired frozen predictions on previously screened external rows."""
import json
from pathlib import Path

import numpy as np


def evaluate(labels, groups, spectral, residual, draws=2000):
    """Probability tensors are aligned as seed, row, class (nonrumor, rumor)."""
    labels, groups = np.asarray(labels), np.asarray(groups)
    spectral, residual = np.asarray(spectral), np.asarray(residual)
    if labels.ndim != 1 or groups.shape != labels.shape or set(labels) != {0, 1}:
        raise ValueError("Aligned rows and both confirmed binary classes are required")
    if spectral.shape != residual.shape or spectral.ndim != 3 or spectral.shape[1:] != (len(labels), 2) or not len(spectral):
        raise ValueError("Expected matching seed-by-row-by-class predictions")
    for values in (spectral, residual):
        if not np.isfinite(values).all() or (values < 0).any() or (values > 1).any() or not np.allclose(values.sum(axis=-1), 1):
            raise ValueError("Invalid probabilities")
    components, membership = np.unique(groups, return_inverse=True)
    if len(components) < 2 or draws < 1:
        raise ValueError("At least two components and one bootstrap draw are required")
    counts = np.zeros((len(components), 2, len(spectral), 2, 2), dtype=np.int64)
    for model, probs in enumerate((spectral, residual)):
        for seed, predictions in enumerate(probs.argmax(axis=-1)):
            np.add.at(counts[:, model, seed], (membership, labels.astype(int), predictions), 1)

    def scores(confusion):
        true_positive = np.diagonal(confusion, axis1=-2, axis2=-1)
        denom = confusion.sum(axis=-1) + confusion.sum(axis=-2)
        return np.divide(2 * true_positive, denom, out=np.zeros_like(denom, dtype=float), where=denom != 0)

    f1 = scores(counts.sum(axis=0))
    contrast = f1[0].mean(axis=-1) - f1[1].mean(axis=-1)
    rng = np.random.default_rng(20261110)
    boot = np.empty(draws)
    for i in range(draws):
        sample = rng.integers(len(components), size=len(components))
        scores_i = scores(counts[sample].sum(axis=0))
        boot[i] = scores_i[0].mean() - scores_i[1].mean()
    return dict(rows=len(labels), components=len(components), spectral_class_f1=f1[0].tolist(),
                residual_class_f1=f1[1].tolist(), seed_differences=contrast.tolist(),
                mean_difference=float(contrast.mean()), interval_95=np.quantile(boot,[.025,.975]).tolist())


if __name__ == "__main__":
    labels = [0, 1, 0, 1]
    groups = ["a", "a", "b", "b"]
    perfect = np.eye(2)[[labels, labels]]
    wrong = perfect[..., ::-1]
    check = evaluate(labels, groups, perfect, wrong)
    assert check["mean_difference"] == 1 and check["interval_95"] == [1, 1]
    assert evaluate(labels, groups, perfect, perfect)["interval_95"] == [0, 0]
    assert evaluate(labels, groups, wrong, perfect)["interval_95"] == [-1, -1]
    for bad in ([0, 0, 0, 0], [0, 1, 0, 2]):
        try:
            evaluate(bad, groups, perfect, wrong)
        except ValueError:
            pass
        else:
            raise AssertionError("Invalid labels were accepted")
    print(json.dumps(check))

